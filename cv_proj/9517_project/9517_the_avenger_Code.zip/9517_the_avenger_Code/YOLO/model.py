from ultralytics import YOLO
model = YOLO('yolov8s-seg.pt')  